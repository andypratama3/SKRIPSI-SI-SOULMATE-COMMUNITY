<!-- Nama Genre Field -->
<div class="form-group">
    {!! Form::label('nama_genre', 'Nama Genre:') !!}
    <p>{{ $genre->nama_genre }}</p>
</div>

