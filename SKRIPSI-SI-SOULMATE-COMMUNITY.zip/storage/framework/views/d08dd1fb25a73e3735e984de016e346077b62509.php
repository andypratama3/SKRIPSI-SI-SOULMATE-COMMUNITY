<div class="table-responsive">
    <table class="table" id="genres-table">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Genre</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                       <td><?php echo e($genre->nama_genre); ?></td>
                       <td class=" text-center">
                           <?php echo Form::open(['route' => ['genres.destroy', $genre->id], 'method' => 'delete']); ?>

                           <div class='btn-group'>
                               <a href="<?php echo route('genres.show', [$genre->id]); ?>" class='btn btn-primary action-btn '><i class="fa fa-eye"></i></a>
                               <a href="<?php echo route('genres.edit', [$genre->id]); ?>" class='btn btn-warning action-btn edit-btn'><i class="fa fa-edit"></i></a>
                               <?php echo Form::button('<i class="fa fa-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger action-btn delete-btn', 'onclick' => 'return confirm("Are you sure want to delete this record ?")']); ?>

                           </div>
                           <?php echo Form::close(); ?>

                       </td>
                   </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->startSection('js'); ?>
<script>
    $('#genres-table').DataTable();
</script>
<?php $__env->stopSection(); ?><?php /**PATH E:\Project\SKRIPSI\SI\SKRIPSI-SI-SOULMATE-COMMUNITY\resources\views/genres/table.blade.php ENDPATH**/ ?>