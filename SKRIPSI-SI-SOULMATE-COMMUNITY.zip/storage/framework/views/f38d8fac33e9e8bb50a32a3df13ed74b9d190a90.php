<div class="table-responsive">
    <table class="table" id="anggotas-table">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama</th>
        <th>Nomor Hp</th>
        <th>Alamat</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $anggotas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anggota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                       <td><?php echo e($anggota->nama); ?></td>
            <td><?php echo e($anggota->nomor_hp); ?></td>
            <td><?php echo e($anggota->alamat); ?></td>
                       <td class=" text-center">
                           <?php echo Form::open(['route' => ['anggotas.destroy', $anggota->id], 'method' => 'delete']); ?>

                           <div class='btn-group'>
                               <a href="<?php echo route('anggotas.show', [$anggota->id]); ?>" class='btn btn-info action-btn '><i class="fa fa-eye"></i></a>
                               <a href="<?php echo route('anggotas.edit', [$anggota->id]); ?>" class='btn btn-warning action-btn edit-btn'><i class="fa fa-edit"></i></a>
                               <?php echo Form::button('<i class="fa fa-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger action-btn delete-btn', 'onclick' => 'return confirm("Are you sure want to delete this record ?")']); ?>

                           </div>
                           <?php echo Form::close(); ?>

                       </td>
                   </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->startSection('js'); ?>
<script>
    $('#anggotas-table').DataTable();
</script>
<?php $__env->stopSection(); ?><?php /**PATH E:\Project\SKRIPSI\SI\SKRIPSI-SI-SOULMATE-COMMUNITY\resources\views/anggotas/table.blade.php ENDPATH**/ ?>