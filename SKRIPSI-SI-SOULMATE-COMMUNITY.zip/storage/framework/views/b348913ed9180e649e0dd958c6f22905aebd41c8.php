<!-- Id Genre Field -->
<div class="form-group">
    <?php echo Form::label('id_genre', 'Genre:'); ?>

    <p><?php echo e($team->idGenre->nama_genre); ?></p>
</div>

<!-- Nama Tim Field -->
<div class="form-group">
    <?php echo Form::label('nama_tim', 'Nama Tim:'); ?>

    <p><?php echo e($team->nama_tim); ?></p>
</div>

<div class="form-group">
    <?php echo Form::label('nama_tim', 'Anggota TIM:'); ?>

   <div class="row">
        <?php $__currentLoopData = $team->teamMembers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-xl-3">
                <div class="card">
                    <div class="card-body pb-0">
                        <div class="text-center">
                            <img src="<?php echo e(($item->Anggota->img==null)?asset('no_image.jpg'):asset('storage/')."/".$item->Anggota->img); ?>" alt="img" class="img-fluid w-100">
                        </div>
                        <div class="card-body px-0 ">
                            <div class="cardprice">
                                <span class="type--strikethrough number-font"><?php echo e($item->Anggota->nama); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </div>
</div><?php /**PATH E:\Project\SKRIPSI\SI\SKRIPSI-SI-SOULMATE-COMMUNITY\resources\views/teams/show_fields.blade.php ENDPATH**/ ?>