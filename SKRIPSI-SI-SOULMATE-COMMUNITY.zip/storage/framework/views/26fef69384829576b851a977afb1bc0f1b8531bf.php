<?php if(Auth::user()->role == 1): ?>
<li class="side-menus <?php echo e(Request::is('home*') ? 'active' : ''); ?>">
    <a class="nav-link" href="/">
        <i class="fas fa-home    "></i><span>Dashboard</span>
    </a>
</li>
<li class="side-menus <?php echo e(Request::is('anggotas*') ? 'active' : ''); ?>"> 
    <a class="nav-link" href="<?php echo e(route('anggotas.index')); ?>"><i class="fas fa-user"></i><span>Anggota</span></a>
</li>

<li class="side-menus <?php echo e(Request::is('genres*') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('genres.index')); ?>"><i class="fas fa-spa"></i><span>Genre</span></a>
</li>
<li class="side-menus <?php echo e(Request::is('teams*') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('teams.index')); ?>"><i class="fas fa-users"></i><span>Team</span></a>
</li>
<li class="side-menus <?php echo e(Request::is('pemesanans*') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('pemesanans.index')); ?>"><i class="fas fa-calendar-check"></i><span>Pemesanan</span></a>
</li>


<?php else: ?>
<li class="side-menus <?php echo e(Request::is('home*') ? 'active' : ''); ?>">
    <a class="nav-link" href="/">
        <i class="fas fa-home    "></i><span>Dashboard</span>
    </a>
</li>
<li class="side-menus <?php echo e(Request::is('pemesanans*') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('pemesanans.index')); ?>"><i class="fas fa-calendar-check"></i><span>Pemesanan</span></a>
</li>
<?php endif; ?><?php /**PATH E:\Project\SKRIPSI 2022\SI\SKRIPSI-SI-SOULMATE-COMMUNITY\resources\views/layouts/menu.blade.php ENDPATH**/ ?>