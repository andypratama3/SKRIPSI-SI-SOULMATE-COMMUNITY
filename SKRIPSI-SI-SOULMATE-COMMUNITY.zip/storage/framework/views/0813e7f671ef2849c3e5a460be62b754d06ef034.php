<?php $__env->startSection('title'); ?>
    Pemesanan Details 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
        <h1>Informasi Pemesanan</h1>
        <div class="section-header-breadcrumb">
            <?php if(Auth::user()->role == 1): ?>
                <?php if($pemesanan->status == 1): ?>
                <a href="<?php echo e(route('pemesanans.terima',[$pemesanan->id])); ?>" class="btn btn-success form-btn float-right">Terima</a>
                <a href="<?php echo e(route('pemesanans.tolak',[$pemesanan->id])); ?>" class="btn btn-danger form-btn float-right">Tolak</a>
                <?php elseif($pemesanan->status == 2): ?>
                <form action="<?php echo e(route('pemesanans.setTim',[$pemesanan->id])); ?>" method="post" style="width: 300px;">
                    <?php echo csrf_field(); ?>
                    <div class="d-flex justify-content-center">
                        <div class="form-group">
                            <?php echo Form::label('id_team', 'Team:'); ?>

                            <?php echo Form::select('id_team',$team, null, ['class' => 'form-control']); ?>

                        </div>
                        <button class="btn btn-primary" type="submit" style="margin-top: 30px;margin-left: 10px;height: 50%;">Atur Tim</button>   
                    </div>
                    
                </form>
                <?php endif; ?>
            <?php else: ?>
                <a href="<?php echo e(route('pemesanans.index')); ?>" class="btn btn-primary form-btn float-right">Back</a>
            <?php endif; ?>
        </div>
      </div>
   <?php echo $__env->make('stisla-templates::common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="section-body">
        <div class="row">
            <?php if(Auth::user()->role == 1): ?>
            <div class="col-md-6">
                <div class="card">
                    <h2 class="section-title">Informasi Pelanggan</h2>
                    <div class="card-body">
                        <div class="form-group">
                            <?php echo Form::label('genre', 'Nama:'); ?>

                            <p><?php echo e($pemesanan->Pelanggan->name); ?></p>
                        </div>
                        <div class="form-group">
                            <?php echo Form::label('genre', 'Nomor HP:'); ?>

                            <p><?php echo e($pemesanan->nomor_hp); ?></p>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            <div class="col-md-6">
                <div class="card">
                    <h2 class="section-title">Informasi Pemesanan</h2>
                    <div class="card-body">
                            <?php echo $__env->make('pemesanans.show_fields', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project\SKRIPSI 2022\SI\SKRIPSI-SI-SOULMATE-COMMUNITY\resources\views/pemesanans/show.blade.php ENDPATH**/ ?>