<!-- Id Genre Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('id_genre', 'Genre:'); ?>

    <?php echo Form::select('id_genre',$genre, null, ['class' => 'form-control']); ?>

</div>

<!-- Nama Tim Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('nama_tim', 'Nama Tim:'); ?>

    <?php echo Form::text('nama_tim', null, ['class' => 'form-control','maxlength' => 50,'maxlength' => 50]); ?>

</div>
<div class="form-group col-sm-12">
    <?php echo Form::label('nama_tim', 'Pilih Anggota Tim:'); ?>

    <div class="custom-controls-stacked">
        <?php $__currentLoopData = $anggota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <label class="custom-control custom-checkbox">
                <input type="checkbox" class="custom-control-input" name="anggotaTim[]" value="<?php echo e($item->id); ?>" >
                <span class="custom-control-label"><?php echo e($item->nama); ?></span>
            </label>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>


<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo e(route('teams.index')); ?>" class="btn btn-light">Cancel</a>
</div>
<?php /**PATH E:\Project\SKRIPSI 2022\SI\SKRIPSI-SI-SOULMATE-COMMUNITY\resources\views/teams/fields.blade.php ENDPATH**/ ?>