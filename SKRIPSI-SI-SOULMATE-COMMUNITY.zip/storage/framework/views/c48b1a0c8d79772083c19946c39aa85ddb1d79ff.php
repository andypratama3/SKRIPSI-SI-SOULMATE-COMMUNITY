<div class="footer-left">
    All rights reserved &copy; <?php echo e(date('Y')); ?>

</div>
<?php /**PATH E:\Project\SKRIPSI\SI\SKRIPSI-SI-SOULMATE-COMMUNITY\resources\views/layouts/footer.blade.php ENDPATH**/ ?>