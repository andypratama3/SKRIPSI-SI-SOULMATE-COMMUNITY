<?php echo Form::hidden('id_admin', Auth::user()->id, ['class' => 'form-control']); ?>

<div class="form-group col-sm-6">
    <?php echo Form::label('id_genre', 'Team:'); ?>

    <?php echo Form::select('id_genre',$genre, null, ['class' => 'form-control']); ?>

</div>
<div class="form-group col-sm-6">
    <?php echo Form::label('waktu_pemesanan', 'Waktu Pemesanan:'); ?>

    <?php echo Form::date('waktu_pemesanan', null, ['class' => 'form-control','id'=>'waktu_pemesanan']); ?>

</div>
<div class="form-group col-sm-12">
    <?php echo Form::label('nomor_hp', 'Nomor HP Yang Bisa Dihubungi:'); ?>

    <?php echo Form::number('nomor_hp', null, ['class' => 'form-control','id'=>'nomor_hp']); ?>

</div>
<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript">
        $('#waktu_pemesanan').datetimepicker({
            format: 'YYYY-MM-DD HH:mm:ss',
            useCurrent: true,
            sideBySide: true
        })
    </script>
<?php $__env->stopPush(); ?>
<div class="form-group col-sm-12 col-lg-12">
    <?php echo Form::label('lokasi', 'Lokasi:'); ?>

    <?php echo Form::textarea('lokasi', null, ['class' => 'form-control']); ?>

</div>
<div class="form-group col-sm-12">
    <label class="form-label">Metode Pembayaran</label>
    <div class="selectgroup w-100">
      <label class="selectgroup-item">
        <input type="radio" name="metode_pembayaran" value="Transafer" class="selectgroup-input" required>
        <span class="selectgroup-button">Transfer</span>
      </label>
      <label class="selectgroup-item">
        <input type="radio" name="metode_pembayaran" value="Tunai" class="selectgroup-input" required>
        <span class="selectgroup-button">Tunai</span>
      </label>
    </div>
  </div>
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo e(route('pemesanans.index')); ?>" class="btn btn-light">Cancel</a>
</div>
<?php /**PATH E:\Project\SKRIPSI\SI\SKRIPSI-SI-SOULMATE-COMMUNITY\resources\views/pemesanans/fields.blade.php ENDPATH**/ ?>