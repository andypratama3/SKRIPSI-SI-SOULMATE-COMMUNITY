<div class="form-group">
    <?php echo Form::label('id_team', 'Team:'); ?>

    <p><?php echo e(($pemesanan->id_team == null)?"Sedang Dicarikan!":$pemesanan->idTeam->nama_tim); ?></p>
</div>
<div class="form-group">
    <?php echo Form::label('genre', 'Genre:'); ?>

    <p><?php echo e($pemesanan->Genre->nama_genre); ?></p>
</div>
<div class="form-group">
    <?php echo Form::label('genre', 'Metode Pembayaran:'); ?>

    <p><?php echo e($pemesanan->metode_pembayaran); ?></p>
</div>
<div class="form-group">
    <?php echo Form::label('waktu_pemesanan', 'Waktu Pemesanan:'); ?>

    <p><?php echo e(date("d F Y", strtotime($pemesanan->waktu_pemesanan))); ?></p>
</div>
<div class="form-group">
    <?php echo Form::label('lokasi', 'Lokasi:'); ?>

    <p><?php echo e($pemesanan->lokasi); ?></p>
</div>

<?php /**PATH E:\Project\SKRIPSI\SI\SKRIPSI-SI-SOULMATE-COMMUNITY\resources\views/pemesanans/show_fields.blade.php ENDPATH**/ ?>