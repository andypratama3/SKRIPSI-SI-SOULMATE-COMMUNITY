<!-- Nama Genre Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('nama_genre', 'Nama Genre:'); ?>

    <?php echo Form::text('nama_genre', null, ['class' => 'form-control','maxlength' => 50,'maxlength' => 50]); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo e(route('genres.index')); ?>" class="btn btn-light">Cancel</a>
</div>
<?php /**PATH E:\Project\SKRIPSI\SI\SKRIPSI-SI-SOULMATE-COMMUNITY\resources\views/genres/fields.blade.php ENDPATH**/ ?>