<?php $__env->startSection('title'); ?>
    Pemesanans 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php if(Auth::user()->role == 1): ?>
        <section class="section">
            <div class="section-header">
                <h1>Pemesanans</h1>
            </div>
            <div class="section-body">
                <div class="card">
                        <div class="card-body">
                            <?php echo $__env->make('pemesanans.table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                </div>
            </div>
        </section>
    <?php else: ?>
        <section class="section">
            <div class="section-header">
                <h1>Pemesananmu</h1>
                <div class="section-header-breadcrumb">
                    <a href="<?php echo e(route('pemesanans.create')); ?>" class="btn btn-primary form-btn">Pemesanan <i class="fas fa-plus"></i></a>
                </div>
            </div>
            <div class="section-body">
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table" id="pemesanans-table">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Genre</th>
                                        <th>Waktu Pemesanan</th>
                                        <th>Lokasi</th>
                                        <th>Status</th>
                                        <th >Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $pemesanans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pemesanan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($pemesanan->Genre->nama_genre); ?></td>
                                        <td><?php echo e(date("d F Y", strtotime($pemesanan->waktu_pemesanan))); ?></td>
                                        <td><?php echo e($pemesanan->lokasi); ?></td>
                                        <td>
                                            <?php if($pemesanan->status == 1): ?>
                                                <span class="badge badge-warning">Menunggu Di Verifikasi</span>
                                            <?php elseif($pemesanan->status == 2): ?>
                                                <span class="badge badge-primary">Pencarian Tim Dance</span>
                                            <?php elseif($pemesanan->status == 3): ?>
                                                <span class="badge badge-success">Selesai</span>
                                                <?php else: ?>
                                                <span class="badge badge-danger">Ditolak</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class=" text-center">
                                            <div class='btn-group'>
                                                <a href="<?php echo route('pemesanans.show', [$pemesanan->id]); ?>" class='btn btn-info action-btn '><i class="fa fa-eye"></i></a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <?php $__env->startSection('js'); ?>
                        <script>
                            $('#pemesanans-table').DataTable();
                        </script>
                        <?php $__env->stopSection(); ?>
                    </div>
                </div>
            </div>
        </section>
    <?php endif; ?>

    
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project\SKRIPSI 2022\SI\SKRIPSI-SI-SOULMATE-COMMUNITY\resources\views/pemesanans/index.blade.php ENDPATH**/ ?>