<?php $__env->startSection('title'); ?>
    Anggota
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h1>Anggotas</h1>
            <div class="section-header-breadcrumb">
                <a href="<?php echo e(route('anggotas.create')); ?>" class="btn btn-primary form-btn">Anggota <i class="fas fa-plus"></i></a>
            </div>
        </div>
    <div class="section-body">
       <div class="card">
            <div class="card-body">
                <?php echo $__env->make('anggotas.table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
       </div>
   </div>
    
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project\SKRIPSI 2022\SI\SKRIPSI-SI-SOULMATE-COMMUNITY\resources\views/anggotas/index.blade.php ENDPATH**/ ?>