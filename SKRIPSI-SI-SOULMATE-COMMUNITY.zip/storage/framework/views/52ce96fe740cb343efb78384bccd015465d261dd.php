<?php $__env->startSection('title'); ?>
    Anggota Details 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
        <h1>Anggota Details</h1>
        <div class="section-header-breadcrumb">
            <a href="<?php echo e(route('anggotas.index')); ?>"
                 class="btn btn-primary form-btn float-right">Back</a>
        </div>
      </div>
   <?php echo $__env->make('stisla-templates::common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="section-body">
           <div class="card">
            <div class="card-body">
                    <?php echo $__env->make('anggotas.show_fields', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            </div>
    </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project\SKRIPSI\SI\SKRIPSI-SI-SOULMATE-COMMUNITY\resources\views/anggotas/show.blade.php ENDPATH**/ ?>