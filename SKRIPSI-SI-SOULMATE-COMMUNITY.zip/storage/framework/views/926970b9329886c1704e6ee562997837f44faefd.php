<div class="table-responsive">
    <table class="table" id="pemesanans-table">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Pelangan</th>
                <th>Team</th>
                <th>Waktu Pemesanan</th>
                <th>Lokasi</th>
                <th>Status</th>
                <th >Action</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $pemesanans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pemesanan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($pemesanan->Pelanggan->name); ?></td>
                <td><?php echo e(($pemesanan->id_team == null)?"Sedang Dicarikan!":$pemesanan->idTeam->nama_tim); ?></td>
                <td><?php echo e(date("d F Y", strtotime($pemesanan->waktu_pemesanan))); ?></td>
                <td><?php echo e($pemesanan->lokasi); ?></td>
                <td>
                    <?php if($pemesanan->status == 1): ?>
                        <span class="badge badge-warning">Menunggu Di Verifikasi</span>
                    <?php elseif($pemesanan->status == 2): ?>
                        <span class="badge badge-primary">Pencarian Tim Dance</span>
                    <?php elseif($pemesanan->status == 3): ?>
                        <span class="badge badge-success">Selesai</span>
                    <?php else: ?>
                        <span class="badge badge-danger">Ditolak</span>
                    <?php endif; ?>
                </td>
                    <td class=" text-center">
                        <?php echo Form::open(['route' => ['pemesanans.destroy', $pemesanan->id], 'method' => 'delete']); ?>

                        <div class='btn-group'>
                            <?php if($pemesanan->status == 1): ?>
                                <a href="<?php echo route('pemesanans.show', [$pemesanan->id]); ?>" class='btn btn-info action-btn '><i class="fas fa-check"></i> </a>
                                <?php echo Form::button('<i class="fas fa-times"></i>', ['type' => 'submit', 'class' => 'btn btn-danger action-btn delete-btn', 'onclick' => 'return confirm("Batalkan Pemesanan ini?")']); ?>

                            <?php elseif($pemesanan->status == 2 ): ?>
                                <a href="<?php echo route('pemesanans.show', [$pemesanan->id]); ?>" class='btn btn-info action-btn '><i class="fas fa-check"></i> </a>
                            <?php else: ?>
                            <a href="<?php echo route('pemesanans.show', [$pemesanan->id]); ?>" class='btn btn-info action-btn '><i class="fas fa-eye"></i> </a>
                            <?php endif; ?>
                           
                        </div>
                        <?php echo Form::close(); ?>

                    </td>
                </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->startSection('js'); ?>
<script>
    $('#pemesanans-table').DataTable();
</script>
<?php $__env->stopSection(); ?><?php /**PATH E:\Project\SKRIPSI 2022\SI\SKRIPSI-SI-SOULMATE-COMMUNITY\resources\views/pemesanans/table.blade.php ENDPATH**/ ?>