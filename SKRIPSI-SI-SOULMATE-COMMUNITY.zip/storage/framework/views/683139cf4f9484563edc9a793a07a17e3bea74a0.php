<!-- Nama Field -->
<div class="form-group">
    <?php echo Form::label('nama', 'Nama:'); ?>

    <p><?php echo e($anggota->nama); ?></p>
</div>

<!-- Nomor Hp Field -->
<div class="form-group">
    <?php echo Form::label('nomor_hp', 'Nomor Hp:'); ?>

    <p><?php echo e($anggota->nomor_hp); ?></p>
</div>

<!-- Alamat Field -->
<div class="form-group">
    <?php echo Form::label('alamat', 'Alamat:'); ?>

    <p><?php echo e($anggota->alamat); ?></p>
</div>

<div class="form-group">
    <div class="text-center">
        <img src="<?php echo e(($anggota->img==null)?asset('no_image.jpg'):asset('storage/')."/".$anggota->img); ?>" alt="img" class="img-fluid w-50" >
    </div>
</div><?php /**PATH E:\Project\SKRIPSI\SI\SKRIPSI-SI-SOULMATE-COMMUNITY\resources\views/anggotas/show_fields.blade.php ENDPATH**/ ?>