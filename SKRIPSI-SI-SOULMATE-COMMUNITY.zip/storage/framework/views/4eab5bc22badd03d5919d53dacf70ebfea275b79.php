<div class="table-responsive">
    <table class="table" id="teams-table">
        <thead>
            <tr>
                <th>No</th>
                <th>Genre</th>
                <th>Nama Tim</th>
                <th class=" text-center">Action</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($team->idGenre->nama_genre); ?></td>
                <td><?php echo e($team->nama_tim); ?></td>
                <td class=" text-center">
                    <?php echo Form::open(['route' => ['teams.destroy', $team->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <a href="<?php echo route('teams.show', [$team->id]); ?>" class='btn btn-info action-btn '><i class="fa fa-eye"></i></a>
                        <a href="<?php echo route('teams.edit', [$team->id]); ?>" class='btn btn-warning action-btn edit-btn'><i class="fa fa-edit"></i></a>
                        <?php echo Form::button('<i class="fa fa-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger action-btn delete-btn', 'onclick' => 'return confirm("Are you sure want to delete this record ?")']); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->startSection('js'); ?>
<script>
    $('#teams-table').DataTable();
</script>
<?php $__env->stopSection(); ?><?php /**PATH E:\Project\SKRIPSI\SI\SKRIPSI-SI-SOULMATE-COMMUNITY\resources\views/teams/table.blade.php ENDPATH**/ ?>